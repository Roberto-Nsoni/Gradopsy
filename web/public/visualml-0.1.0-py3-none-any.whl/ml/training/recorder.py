import numpy as np

class Recorder:
    """
    Keeps the snapshot of every step so the viz can scrub back and forth through the
    training instead of only seeing the end of it.

    `every` subsamples: on a 2D surface you can keep all of it, but on MNIST there are
    101k parameters times 19k steps and that does not fit anywhere.
    """
    def __init__(self, every: int = 1):
        self.every = every
        self.frames: list[dict] = []

    def __len__(self) -> int:
        return len(self.frames)

    def __getitem__(self, i) -> dict:
        return self.frames[i]

    def add(self, snapshot: dict) -> dict:
        if snapshot["k"] % self.every == 0:
            self.frames.append(snapshot)

        return snapshot

    def column(self, key: str):
        """That field along the whole run, as an array. For plotting a curve."""
        return np.array([frame[key] for frame in self.frames])

    def columns(self) -> dict:
        """
        The whole recording turned inside out: instead of a list of dicts, one array per
        field, stacked over time. It is what the frontend wants to read, and what save writes.
        """
        out = {}

        for key in self.frames[0]:
            if key == "state":
                for state_key in self.frames[0]["state"]:
                    values = [frame["state"].get(state_key) for frame in self.frames]

                    # Newton no tiene Hessiana en un paso que arranca ya en un punto estacionario
                    if any(v is None for v in values):
                        continue

                    out[f"state_{state_key}"] = np.array(values)
            else:
                out[key] = self.column(key)

        return out

    def save(self, path) -> None:
        np.savez_compressed(path, **self.columns())
